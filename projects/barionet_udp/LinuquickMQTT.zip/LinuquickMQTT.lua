module = {};

require('io');
mqtt = require("mosquitto");
json = require('json');
http = require("socket.http");
str_utils = require('str_utils');

qos = 1;
retain = false;

function module.log(str)
	io.write("|LinuquickMQTT| ");
	io.write(str,'\n');
	io.flush();
end

function module.disconnect()
  if module.client==nil then
    module.log('MQTT Client is not yet connected');
    return false;
  end
  local val = module.client:disconnect();
  if val<0 then
    module.log('MQTT Disconnect failed');
    return false;
  end;
  module.client = nil;
  return true;
end

function module.sendStatus(state)
  if module.client==nil then
    module.log('MQTT Client is not yet connected');
    return false;
  end;
  module.log('Sending status: '..state);
  module.client:publish(module.pubTopic,json.encode({type="SetStatus",deviceId=module.deviceId,status=state}),qos,retain);
  return true;
end

function module.getConfig()
	return module.config;
end

function module.sendConfigRequest()
  if module.client==nil then
    module.log('MQTT Client is not yet connected');
    return false;
  end;
  module.log('Sending config request');
  module.client:publish(module.pubTopic,json.encode({type="GetConfig",deviceId=module.deviceId}),qos,retain);
  return true;
end

function module.start(on_configchange)
	local f = io.open('/root/flexa/regId','r');
	if f==nil then
		module.log('Cannot open file /root/flexa/regId');
		return false;
	end;
	local str = f:read('*a');
	f:close();
	if #str==0 then
	    module.log('File /root/flexa/regId is empty');
	    return false;
	end
	deviceId = str;
	module.deviceId = deviceId;

	--Try to load current config
	f = io.open('/root/flexa/config','r');
	if f~=nil then
		local confStr = f:read('*a');
		if confStr~=nil and #confStr>0 then
			module.config = json.decode(confStr);
		end
	end

 	sasGeneratorUrl = "https://barixiotnew.azurewebsites.net/api/GenerateSAS";

	module.on_configchange = on_configchange;
  
	module.sasGeneratorUrl = sasGeneratorUrl;
  
    local request_body = json.encode({deviceId=deviceId});
    local response_body = {};

    local res, code, response_headers = http.request{
    	url = sasGeneratorUrl,
    	method = "POST", 
    	headers = {
        	["Content-Type"] = "application/json;charset=UTF-8";
        	["Content-Length"] = #request_body;
      	},
      	source = ltn12.source.string(request_body),
      	sink = ltn12.sink.table(response_body)
  	}

  	module.log('SAS generator response code: '..code);

  	if code~=200 then
   		module.log('SAS generator response code not OK!');
    	return false;
  	end
  
  	local response_str = table.concat(response_body);
  	if response_str == nil or #response_str==0 then
    	module.log('SAS generator responded with empty response');
    	return false;
  	end
  	local response_json = json.decode(response_str);
  	if response_json==nil then
    	module.log('SAS generator response cannot be JSON decoded');
    	return false;
  	end
  	module.password = response_json.password;
	module.port = response_json.port;
	module.broker = response_json.broker;
	module.pubTopic = response_json.pubTopic;
	module.subTopic = response_json.subTopic;
	module.username = response_json.username;
	module.clientId = response_json.clientId;

  	--We got everything we need to establish connection.
  	--Certificate file should be always the same since we are always connecting to MS azure, so let's just always use digiCert.cer
  	module.client = mqtt.new(module.clientId, true);
  	module.client:login_set(module.username,module.password);
  	module.client:set_version(4); --Set to MQTT 3.1.1
  	module.client:tls_set("LinuquickMQTT/certificate/digiCert.cer");
  	module.client:tls_insecure_set(false);
  
    module.client.ON_CONNECT = function()
      io.write("MQTT Connected!\n");
      io.flush();
  	  module.client:subscribe(module.subTopic,1);
  	  module.log('MQTT All subscribed');
  	  if module.config==nil then
	  	--Ask for configuration
	  	module.log("Asking for config");
	  	module.sendConfigRequest();
  	  end
	  module.log("Sending current status");
	  module.sendStatus("Alive");
    end;

  	--Set up functions
  	module.client.ON_DISCONNECT = function(str1,str2,str3)
      --Auto-reconnects..
      io.write("MQTT Disconnected!\n");
      io.flush();
  	end;
  
  	module.client.ON_MESSAGE = function(mid,topic,payload)
    	module.log("[Message received] Topic: "..topic.." Payload: "..payload);
    	if payload~=nil and #payload>0 then
	      	local msg = json.decode(payload);
	      	if msg.type=='GetConfig' then
	      		module.config = msg.AppParam;

	      		local f = io.open("/root/flexa/config",'w');
	      		if f~=nil then
	      			f:write(json.encode(module.config));
	      			f:close();
	      		end

	      		if module.on_configchange~=nil then
	      			module.on_configchange(module.config);
	      		end
	      	elseif msg.type=='SetStatus' then
	      		if msg.config=='new' then
	      			module.sendConfigRequest();
	      		elseif msg.config=='reboot' then
	      			os.execute('reboot');
	      		end
	      	end
    	end
  	end;
  
  	module.client:loop_start();

  	module.client:connect(module.broker,module.port);
  	return true;
end

return module;